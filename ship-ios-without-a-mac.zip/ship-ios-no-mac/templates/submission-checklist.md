# App Store Submission Checklist
## Print this. Run it top to bottom before every submission.

## Build
- [ ] Version + build number bumped in pubspec.yaml (build number higher than last upload)
- [ ] Build green on Codemagic, .ipa uploaded to TestFlight
- [ ] Installed via TestFlight on a real device and smoke-tested: launch, sign-up, core flow, purchase flow, sign-out

## App Store Connect listing
- [ ] App name (30 chars max) and subtitle (30 chars max)
- [ ] Description — first 3 lines carry the hook (that's all that shows before "more")
- [ ] Keywords field (100 chars, comma-separated, no spaces after commas, don't repeat words from your app name)
- [ ] Screenshots: 6.9" (1320 × 2868) and 6.5" (1284 × 2778 or 1242 × 2688) — taken from the current build
- [ ] Support URL and Marketing URL live
- [ ] Privacy Policy URL live and loading (GitHub Pages works)
- [ ] Age rating questionnaire done
- [ ] Category (primary + secondary) chosen

## Monetisation (if paid features)
- [ ] IAP/subscription products created in App Store Connect AND submitted with the build (new IAPs must be attached to a version the first time)
- [ ] Paywall shows price, duration, auto-renewal wording
- [ ] Privacy Policy + Terms/EULA links tappable on paywall
- [ ] EULA link also in the app description field

## Compliance
- [ ] App Privacy questionnaire matches every SDK (Firebase = identifiers + usage data at minimum)
- [ ] In-app account deletion works end-to-end (if accounts exist)
- [ ] All Info.plist permission strings present and human-readable
- [ ] Export compliance: ITSAppUsesNonExemptEncryption set, or question answered in ASC

## Review information
- [ ] Demo account credentials entered — tested TODAY
- [ ] Review notes: where to find account deletion, anything non-obvious, hardware needs
- [ ] Contact phone + email current

## After submitting
- [ ] Expect 24-72h for first review
- [ ] If rejected: read whether it's binary or metadata-only; fix; reply in Resolution Center with exactly what changed; resubmit
- [ ] Log the rejection reason — you're building a pattern library that makes every future submission faster
