# The App Store Rejection Playbook
## The rejections you'll actually get, and exactly how to clear them

Apple rejects a huge share of first submissions. A rejection is not a verdict — it's a checklist item. Each entry below: what the rejection email says, what Apple actually means, and the fastest fix.

---

## Guideline 2.1 — "App completeness" (missing demo account)

**What it says:** "We were unable to sign in with the credentials provided" or "Please provide a demo account."

**What it means:** Your app has a login and the reviewer couldn't get past it.

**Fix:** Create a real, working demo account in your production database. Put the credentials in App Review Information → Sign-in required. Test the credentials yourself the day you submit — a demo account that has expired or hits an edge case is the most common repeat rejection. If your app supports Sign in with Apple only, you must still explain how the reviewer gets in.

## Guideline 3.1.2 — Subscription information requirements

**What it says:** Your subscription doesn't clearly display price, duration, and terms before purchase.

**What it means:** Apple wants, on the paywall screen itself: subscription title, length, price per period, and functional links to your Privacy Policy and Terms of Use (EULA). "Functional" means the reviewer will tap them.

**Fix:**
- Paywall must state e.g. "£4.99/month, auto-renews until cancelled"
- Add tappable Privacy Policy and Terms of Use links on the paywall
- If you use Apple's standard EULA, link to it: apple.com/legal/internet-services/itunes/dev/stdeula
- Also paste the EULA link into the App Description field in App Store Connect — reviewers check both places

## Guideline 5.1.1(v) — Account deletion

**What it says:** Apps that support account creation must also let users delete their account, in-app.

**What it means:** A link to a website form is usually not enough if creation happens in-app. Deletion must be findable and must actually delete (not just deactivate).

**Fix:** Add Settings → Delete Account → confirmation → actually remove the auth record and user data (for Firebase: delete the Auth user and their Firestore documents). Describe where it lives in your review notes so the reviewer finds it first try.

## Guideline 4.3 — Spam / design minimum

**What it says:** "Your app duplicates content or functionality available on the App Store."

**What it means:** Reviewer thinks your app is a template or too thin.

**Fix:** Ship one genuinely distinctive feature and lead with it in screenshots and description. In your reply to App Review, explain concretely what your app does that the category leaders don't. Appeals on 4.3 succeed when they're specific.

## Guideline 2.3.3 — Screenshot accuracy

**What it says:** Screenshots don't reflect the app in use.

**Fix:** Screenshots must show the actual UI on the actual device size. Marketing-only images, wrong device frames, or features not in the build all trigger this. Retake them from your TestFlight build.

## Guideline 5.1.1 — Data collection and privacy

**What it says:** Privacy policy missing/unreachable, or App Privacy answers don't match observed behavior.

**Fix:** Host your privacy policy at a stable public URL (GitHub Pages is free and fine). Ensure your App Privacy questionnaire declares everything your SDKs collect — Firebase Analytics alone means declaring identifiers and usage data. Mismatches between the questionnaire and network traffic get caught.

## Metadata rejections (no binary change needed)

If the rejection is only about your listing (keywords, description, screenshots), you can fix and resubmit without a new build — resolution is usually faster. Read the rejection carefully to see whether they've flagged the binary or the metadata.

---

## How to respond to any rejection

1. **Don't argue in the first reply. Fix and resubmit.** Resubmissions after a clean fix are often reviewed faster than the original.
2. **Reply in Resolution Center describing exactly what changed** ("Added in-app account deletion under Settings → Account → Delete Account; demo account credentials updated").
3. **Only appeal when you genuinely believe the guideline doesn't apply** — and then cite the guideline number and be specific.
4. **Track every rejection reason across your apps.** Patterns repeat. Your third submission should sail through the mistakes your first one hit.

## Pre-submission kill list

Run this before every single submission — it clears the five most common rejections in advance:

- [ ] Demo account created, tested today, credentials in review notes
- [ ] Paywall shows price + duration + auto-renewal wording
- [ ] Privacy Policy and Terms/EULA links tappable on the paywall AND EULA link in app description
- [ ] In-app account deletion working end-to-end
- [ ] Screenshots taken from the current build, correct sizes
- [ ] App Privacy questionnaire matches every SDK in the app
- [ ] All permission usage-descriptions present in Info.plist
