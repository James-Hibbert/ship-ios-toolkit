# Ship iOS Without a Mac
## The complete Windows-to-App-Store pipeline for Flutter developers

You do not need a Mac to ship an iOS app. You need an Apple Developer account (£79/year), a Codemagic account (free tier works to start), and this guide. Everything below has been used to ship real apps to the App Store from a Windows machine.

---

## Part 1: The mental model

Apple's tooling (Xcode) only runs on macOS. But you don't need Xcode on *your* machine — you need it on *a* machine. Codemagic (a CI/CD service) rents you a Mac in the cloud for the few minutes each build takes. Your job is to configure your project so that a machine you never touch can build, sign, and upload it.

The pipeline:

1. Your Flutter code lives on GitHub
2. Codemagic pulls it, builds it on a cloud Mac, signs it with your Apple certificates
3. The signed .ipa uploads straight to TestFlight
4. You test on a physical iPhone via TestFlight, then promote to App Store review

You will never open Xcode. Every Xcode-only task has a workaround covered below.

## Part 2: Apple Developer account setup

1. Enroll at developer.apple.com (£79/year, takes 24-48h to approve).
2. In App Store Connect, create your app record: Apps → + → New App. You'll need a bundle ID (e.g. `com.yourname.appname`) — register it under Certificates, Identifiers & Profiles → Identifiers first.
3. Create an **App Store Connect API key** (Users and Access → Integrations → App Store Connect API). Role: App Manager. Download the .p8 file — you only get one download, store it safely. Note the Key ID and Issuer ID. This key is how Codemagic authenticates as you; it replaces every "log into Xcode" step.

## Part 3: Code signing without Xcode

This is where most Windows developers give up. Don't — Codemagic automates it.

1. In Codemagic: Teams → Personal Account → Integrations → connect your App Store Connect API key (paste Key ID, Issuer ID, upload the .p8).
2. Under Settings → Code signing identities, let Codemagic **generate** your iOS Distribution certificate and provisioning profile automatically using that API key. Do not try to create certificates manually on Windows via OpenSSL unless you enjoy pain — the automatic route works.
3. Name them clearly (e.g. `yourapp-distribution-cert`, `yourapp-app-store-profile`). You'll reference these names in your codemagic.yaml.

## Part 4: Project configuration from Windows

Things normally done in Xcode's GUI, done in text files instead:

**Bundle ID** — set in `ios/Runner.xcodeproj/project.pbxproj`: search for `PRODUCT_BUNDLE_IDENTIFIER` and set all occurrences to your registered bundle ID.

**Minimum iOS version** — two places must agree:
- `project.pbxproj`: all `IPHONEOS_DEPLOYMENT_TARGET` entries (e.g. `15.0`)
- `ios/Podfile`: uncomment and set `platform :ios, '15.0'`

**App version and build number** — controlled from `pubspec.yaml` (`version: 1.0.0+15` → version 1.0.0, build 15). Every upload to TestFlight needs a higher build number than the last.

**Firebase (if used)** — download `GoogleService-Info.plist` from Firebase console (iOS app registered with your exact bundle ID) and place it at `ios/Runner/GoogleService-Info.plist`. Commit it (or inject via Codemagic environment variables if the repo is public).

**App icons** — generate all sizes with the `flutter_launcher_icons` package. No Xcode asset catalog editing needed.

**Permissions** — any camera/location/notification usage needs a usage-description string in `ios/Runner/Info.plist` (e.g. `NSCameraUsageDescription`). Missing these = instant rejection or crash on review.

## Part 5: The codemagic.yaml

The full working template is in `templates/codemagic.yaml`. Key sections:

- `integrations → app_store_connect`: references your API key by the name you gave it in Codemagic
- `ios_signing`: references your distribution cert and provisioning profile by name
- `scripts`: flutter pub get → pod install → flutter build ipa
- `publishing → app_store_connect`: auto-submits the build to TestFlight

Commit this file to your repo root. Every push to your chosen branch triggers a build. First build takes 15-25 minutes; you get ~500 free build minutes/month on the free tier.

## Part 6: Common build failures and fixes

**Pod install fails / dependency conflicts** — delete `ios/Podfile.lock`, commit, rebuild. If a plugin demands a newer iOS version, raise your deployment target (Part 4) to match.

**"No profiles found" / signing errors** — the bundle ID in your pbxproj doesn't exactly match the provisioning profile's. Case-sensitive. Check every occurrence.

**Build succeeds but no TestFlight upload** — check the publishing section references the right API key name, and that build number is higher than the last uploaded one.

**Export compliance blocking TestFlight** — add `ITSAppUsesNonExemptEncryption` = `false` to Info.plist (assuming you only use standard HTTPS), or answer the compliance question once in App Store Connect.

## Part 7: Testing without owning the build machine

You still need one physical iPhone (borrow one if needed — a 5-year-old model is fine). Install TestFlight from the App Store, accept your own internal-tester invite, and test the real signed build. Simulators are not available to you, and honestly the real device is the better test anyway — review happens on real devices.

## Part 8: Submission

Once a TestFlight build is solid:

1. Complete the App Store listing: name, subtitle, description, keywords, screenshots (see `templates/submission-checklist.md` for exact screenshot sizes and the full pre-flight list)
2. Fill in the App Privacy questionnaire — every SDK you use (Firebase, ads, analytics) has declared data types; check each vendor's documentation
3. Attach the build, add review notes (include a demo account if your app has login — this is mandatory, not optional)
4. Submit. First reviews typically take 24-72 hours.

Rejections are normal. The rejection playbook in `guide/02-app-store-rejection-playbook.md` covers the ones you're statistically most likely to hit and exactly how to respond.

---

*You now have a pipeline where "release to iPhone users worldwide" is: bump the version in pubspec.yaml, git push, wait 20 minutes. From a Windows laptop.*
