# Ship iOS Without a Mac — Toolkit

Thanks for grabbing this. Here's the fastest route through it:

1. **guide/01-ship-ios-from-windows.md** — read once end-to-end (20 min), then work through Parts 2-5 with your project open.
2. **templates/codemagic.yaml** — copy into your repo root, replace the 5 placeholders marked at the top.
3. **templates/submission-checklist.md** — run before every submission.
4. **guide/02-app-store-rejection-playbook.md** — read the pre-submission kill list now; return to the full playbook the day a rejection lands.

Questions or something Apple changed? Reply to your Gumroad receipt — updates are free forever.
